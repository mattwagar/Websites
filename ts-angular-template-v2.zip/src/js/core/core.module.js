var app;
(function (app) {
    'use strict';
    angular.module('app.core', []);
})(app || (app = {}));

//# sourceMappingURL=core.module.js.map
