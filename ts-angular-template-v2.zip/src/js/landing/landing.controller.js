var app;
(function (app) {
    'use strict';
    LandingController.$inject = [];
    var LandingController = (function () {
        function LandingController() {
        }
        return LandingController;
    }());
    angular
        .module('app.landing')
        .controller('LandingController', LandingController);
})(app || (app = {}));

//# sourceMappingURL=landing.controller.js.map
