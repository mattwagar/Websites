var app;
(function (app) {
    'use strict';
    angular.module('app.landing', []);
})(app || (app = {}));

//# sourceMappingURL=landing.module.js.map
