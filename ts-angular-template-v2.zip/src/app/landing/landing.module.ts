namespace app {
  'use strict';

  angular.module('app.landing', []);
}
