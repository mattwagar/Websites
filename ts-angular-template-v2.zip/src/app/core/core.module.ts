namespace app {
  'use strict';

  angular.module('app.core', []);
}
