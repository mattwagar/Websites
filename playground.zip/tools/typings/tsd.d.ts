/// <reference path="angularjs/angular.d.ts" />
