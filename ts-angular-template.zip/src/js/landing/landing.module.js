(function () {
    'use strict';
    angular.module('app.landing', []);
})();
//# sourceMappingURL=landing.module.js.map