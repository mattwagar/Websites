(function () {
    'use strict';
    angular.module('app.core', []);
})();
//# sourceMappingURL=core.module.js.map