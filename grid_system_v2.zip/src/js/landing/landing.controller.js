var template;
(function (template) {
    'use strict';
    LandingController.$inject = [];
    var LandingController = (function () {
        function LandingController() {
        }
        return LandingController;
    }());
    angular
        .module('app.landing')
        .controller('LandingController', LandingController);
})(template || (template = {}));

//# sourceMappingURL=landing.controller.js.map
