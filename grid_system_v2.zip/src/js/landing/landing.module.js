var template;
(function (template) {
    'use strict';
    angular.module('app.landing', []);
})(template || (template = {}));

//# sourceMappingURL=landing.module.js.map
