namespace template {
  'use strict';

  angular.module('app.landing', []);
}
