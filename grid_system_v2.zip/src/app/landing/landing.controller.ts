namespace template {
    'use strict';

    LandingController.$inject = [];

    class LandingController {
        // static $inject: Array<string> = [''];
        // constructor(/*public... include all services*/) {}
    }
angular
        .module('app.landing')
        .controller('LandingController', LandingController);
}
