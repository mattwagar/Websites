(function() {
    'use strict';

    angular
        .module('app.core')
        .factory('d3f', d3f);

    function d3f() {

        var d3v = d3;
        // insert d3 code here
        return d3v;

    }

})();
